package view;
import CharacterP.Character;
import CharacterP.디아루가;
import CharacterP.수댕이;
import CharacterP.아르세우스;
import CharacterP.파이리;
import CharacterP.피카츄;
import WeaponP.Weapon;

import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.Font;
import javax.swing.JTextArea;
import javax.swing.JButton;
import javax.swing.JProgressBar;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.SystemColor;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.Timer;
import java.util.Random;
import java.util.HashMap;
import java.util.Map;
import javax.swing.JLayeredPane;


public class PokemonAttack extends JFrame {
	public Character player;
	public Character target;
	private int lastInputNumber = -1;
	// phase: 0: 게임 시작 화면 (gameStartImageLabel), 1: 캐릭터 선택 화면 (charSelectBackgroundLabel),
	//        2: 캐릭터 선택 중 (charSelectingBackgroundLabel), 3: 전투 중 (플레이어 턴), 4: 전투 중 (타겟 턴),
	//        5: 게임 종료 (승리/패배 화면)
	int phase = 0;

	private static final long serialVersionUID = 1L;
    private JLayeredPane layeredPane;

	private JLabel EnemyRealHP;
	private JProgressBar EnemyprogressBar;
	private JButton AttackButton0;
	private JButton AttackButton1;
	private JButton OkayBtn;
    private JButton RestartButton;
	private JTextArea textArea;
	private JTextField inputField;

	private JLabel MyPokemonNameLabel;
	private JLabel EnemyPokemonNameLabel;
	private JLabel MYRealHP;
	private JLabel MYFullHP;
	private JProgressBar MyprogressBar;

    private Map<String, JLabel> playerPokemonImageLabels = new HashMap<>();
    private Map<String, JLabel> targetPokemonImageLabels = new HashMap<>();

    private JLabel bar;
    private JLabel MyHP;
    private JLabel EnemyHP;
    private JLabel bar2;
    private JLabel EnemyFullHP;

    private JLabel backgroundLabel; // 전투 배경 이미지 (숲)
    private JLabel gameStartImageLabel; // 게임 시작 이미지
    private JLabel charSelectBackgroundLabel; // 1. 🔹 캐릭터 선택 초기 배경 이미지 추가 🔹
    private JLabel charSelectingBackgroundLabel; // 1. 🔹 캐릭터 선택 중 배경 이미지 추가 🔹
    private JLabel victoryImageLabel;
    private JLabel defeatImageLabel;


	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					PokemonAttack frame = new PokemonAttack();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public PokemonAttack() {

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);

        layeredPane = new JLayeredPane();
        layeredPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        layeredPane.setLayout(null);
        setContentPane(layeredPane);


        // 배경 이미지 (가장 낮은 레이어)
        backgroundLabel = new JLabel("");
        backgroundLabel.setIcon(new ImageIcon(PokemonAttack.class.getResource("/images/전투배경숲.png")));
        backgroundLabel.setBounds(0, 0, 450, 300);
        layeredPane.add(backgroundLabel, JLayeredPane.DEFAULT_LAYER);
        backgroundLabel.setVisible(false);

        // 게임 시작 이미지 (배경보다 약간 높은 레이어)
        gameStartImageLabel = new JLabel("");
        gameStartImageLabel.setIcon(new ImageIcon(PokemonAttack.class.getResource("/images/게임시작.png")));
        gameStartImageLabel.setBounds(0, 0, 450, 300);
        layeredPane.add(gameStartImageLabel, JLayeredPane.PALETTE_LAYER);

        // 1. 🔹 캐릭터 선택 초기 배경 이미지 초기화 🔹
        charSelectBackgroundLabel = new JLabel("");
        charSelectBackgroundLabel.setIcon(new ImageIcon(PokemonAttack.class.getResource("/images/캐릭터선택.png")));
        charSelectBackgroundLabel.setBounds(0, 0, 450, 300);
        layeredPane.add(charSelectBackgroundLabel, JLayeredPane.DEFAULT_LAYER);
        charSelectBackgroundLabel.setVisible(false);

        // 1. 🔹 캐릭터 선택 중 배경 이미지 초기화 🔹
        charSelectingBackgroundLabel = new JLabel("");
        charSelectingBackgroundLabel.setIcon(new ImageIcon(PokemonAttack.class.getResource("/images/캐릭터선택중.png"))); // 이 파일 필요!
        charSelectingBackgroundLabel.setBounds(0, 0, 450, 300);
        layeredPane.add(charSelectingBackgroundLabel, JLayeredPane.DEFAULT_LAYER);
        charSelectingBackgroundLabel.setVisible(false);
                
                
                        // 승리/패배 이미지 화면 초기화
                        victoryImageLabel = new JLabel("");
                        victoryImageLabel.setIcon(new ImageIcon(PokemonAttack.class.getResource("/images/승리.png")));
                        victoryImageLabel.setBounds(-27, -50, 476, 371);
                        layeredPane.add(victoryImageLabel, JLayeredPane.MODAL_LAYER);
                        victoryImageLabel.setVisible(false);
        
                defeatImageLabel = new JLabel("");
                defeatImageLabel.setIcon(new ImageIcon(PokemonAttack.class.getResource("/images/패배.png")));
                defeatImageLabel.setBounds(-18, -15, 487, 300);
                layeredPane.add(defeatImageLabel, JLayeredPane.MODAL_LAYER);
                defeatImageLabel.setVisible(false);


		// JTextArea (로그 출력용)
		textArea = new JTextArea();
		textArea.setBackground(SystemColor.activeCaptionBorder);
		textArea.setLineWrap(true);
		textArea.setWrapStyleWord(true);
		textArea.setEditable(false);
		JScrollPane scrollPane = new JScrollPane(textArea);
		scrollPane.setBounds(6, 198, 438, 68);
		layeredPane.add(scrollPane, JLayeredPane.PALETTE_LAYER);


		// JTextField (입력 필드)
		inputField = new JTextField();
		inputField.setBounds(200, 170, 117, 29); // OkayBtn과 동일 Y축
		layeredPane.add(inputField, JLayeredPane.PALETTE_LAYER);
		inputField.setColumns(10);
		inputField.setVisible(false);


		// 포켓몬 이름 표시용 JLabel들
		MyPokemonNameLabel = new JLabel("내 포켓몬");
		MyPokemonNameLabel.setForeground(SystemColor.activeCaption);
		MyPokemonNameLabel.setFont(new Font("Lucida Grande", Font.PLAIN, 15));
		MyPokemonNameLabel.setBounds(152, 128, 100, 16);
		layeredPane.add(MyPokemonNameLabel, JLayeredPane.PALETTE_LAYER);
		MyPokemonNameLabel.setVisible(false);

		EnemyPokemonNameLabel = new JLabel("적 포켓몬");
		EnemyPokemonNameLabel.setFont(new Font("Lucida Grande", Font.PLAIN, 15));
		EnemyPokemonNameLabel.setBounds(244, 31, 100, 16);
		layeredPane.add(EnemyPokemonNameLabel, JLayeredPane.PALETTE_LAYER);
		EnemyPokemonNameLabel.setVisible(false);


		// 플레이어 포켓몬 이미지 JLabel들 생성 및 Map에 추가
		// 레이어: PALETTE_LAYER (배경 위에 오지만, MODAL_LAYER나 DRAG_LAYER보다는 아래)
		int playerImgX = 36;
		int playerImgY = 59;
		int playerImgWidth = 135;
		int playerImgHeight = 145;
		createAndAddPokemonImageLabel("피카츄", playerPokemonImageLabels, playerImgX, playerImgY, playerImgWidth, playerImgHeight, JLayeredPane.PALETTE_LAYER);
		createAndAddPokemonImageLabel("파이리", playerPokemonImageLabels, playerImgX, playerImgY, playerImgWidth, playerImgHeight, JLayeredPane.PALETTE_LAYER);
		createAndAddPokemonImageLabel("수댕이", playerPokemonImageLabels, playerImgX, playerImgY, playerImgWidth, playerImgHeight, JLayeredPane.PALETTE_LAYER);
		createAndAddPokemonImageLabel("아르세우스", playerPokemonImageLabels, playerImgX, playerImgY, playerImgWidth, playerImgHeight, JLayeredPane.PALETTE_LAYER);
		createAndAddPokemonImageLabel("디아루가", playerPokemonImageLabels, playerImgX, playerImgY, playerImgWidth, playerImgHeight, JLayeredPane.PALETTE_LAYER);

		// 타겟 포켓몬 이미지 JLabel들 생성 및 Map에 추가
		int targetImgX = 299;
		int targetImgY = 0;
		int targetImgWidth = 118;
		int targetImgHeight = 130;
		createAndAddPokemonImageLabel("피카츄", targetPokemonImageLabels, targetImgX, targetImgY, targetImgWidth, targetImgHeight, JLayeredPane.PALETTE_LAYER);
		createAndAddPokemonImageLabel("파이리", targetPokemonImageLabels, targetImgX, targetImgY, targetImgWidth, targetImgHeight, JLayeredPane.PALETTE_LAYER);
		createAndAddPokemonImageLabel("수댕이", targetPokemonImageLabels, targetImgX, targetImgY, targetImgWidth, targetImgHeight, JLayeredPane.PALETTE_LAYER);
		createAndAddPokemonImageLabel("아르세우스", targetPokemonImageLabels, targetImgX, targetImgY, targetImgWidth, targetImgHeight, JLayeredPane.PALETTE_LAYER);
		createAndAddPokemonImageLabel("디아루가", targetPokemonImageLabels, targetImgX, targetImgY, targetImgWidth, targetImgHeight, JLayeredPane.PALETTE_LAYER);


		// HP 관련 JLabel, ProgressBar 초기화
		MYRealHP = new JLabel("100");
		MYRealHP.setBounds(303, 173, 61, 16);
		layeredPane.add(MYRealHP, JLayeredPane.PALETTE_LAYER);
		MYRealHP.setVisible(false);

		bar = new JLabel("/");
		bar.setBounds(325, 173, 25, 16);
		layeredPane.add(bar, JLayeredPane.PALETTE_LAYER);
		bar.setVisible(false);

		MyHP = new JLabel("HP");
		MyHP.setBounds(140, 156, 61, 16);
		layeredPane.add(MyHP, JLayeredPane.PALETTE_LAYER);
		MyHP.setVisible(false);

		MYFullHP = new JLabel("100");
		MYFullHP.setBounds(333, 173, 61, 16);
		layeredPane.add(MYFullHP, JLayeredPane.PALETTE_LAYER);
		MYFullHP.setVisible(false);

		MyprogressBar = new JProgressBar();
		MyprogressBar.setValue(100);
		MyprogressBar.setForeground(new Color(255, 17, 0));
		MyprogressBar.setBounds(162, 156, 190, 20);
		layeredPane.add(MyprogressBar, JLayeredPane.PALETTE_LAYER);
		MyprogressBar.setVisible(false);

		EnemyHP = new JLabel("HP");
		EnemyHP.setBounds(72, 46, 61, 16);
		layeredPane.add(EnemyHP, JLayeredPane.PALETTE_LAYER);
		EnemyHP.setVisible(false);

		EnemyRealHP = new JLabel("100");
		EnemyRealHP.setBounds(219, 59, 61, 16);
		layeredPane.add(EnemyRealHP, JLayeredPane.PALETTE_LAYER);
		EnemyRealHP.setVisible(false);

		bar2 = new JLabel("/");
		bar2.setBounds(244, 59, 25, 16);
		layeredPane.add(bar2, JLayeredPane.PALETTE_LAYER);
		bar2.setVisible(false);

		EnemyFullHP = new JLabel("100");
		EnemyFullHP.setBounds(254, 59, 61, 16);
		layeredPane.add(EnemyFullHP, JLayeredPane.PALETTE_LAYER);
		EnemyFullHP.setVisible(false);

		EnemyprogressBar = new JProgressBar();
		EnemyprogressBar.setValue(100);
		EnemyprogressBar.setForeground(new Color(255, 17, 0));
		EnemyprogressBar.setBounds(94, 46, 190, 20);
		layeredPane.add(EnemyprogressBar, JLayeredPane.PALETTE_LAYER);
		EnemyprogressBar.setVisible(false);


        // OkayBtn 초기화
		OkayBtn = new JButton("확인");
		OkayBtn.setBounds(327, 170, 117, 29); // 기존 위치 유지
		layeredPane.add(OkayBtn, JLayeredPane.MODAL_LAYER); // 🔹 MODAL_LAYER에 추가 🔹
		OkayBtn.setVisible(false);


        // 포켓몬 무기 선택 버튼 위치 및 크기 조정
        AttackButton0 = new JButton("공격0");
        AttackButton0.setBounds(230, 120, 96, 30);
        layeredPane.add(AttackButton0, JLayeredPane.PALETTE_LAYER);
        AttackButton0.setVisible(false);

        AttackButton1 = new JButton("공격1");
        AttackButton1.setBounds(342, 120, 88, 30);
        layeredPane.add(AttackButton1, JLayeredPane.PALETTE_LAYER);
        AttackButton1.setVisible(false);


        // 재시작 버튼 초기화 (위치 조정)
        RestartButton = new JButton("재시작");
        RestartButton.setBounds(180, 200, 100, 30); // 화면 하단 중앙 (y=260)
        layeredPane.add(RestartButton, JLayeredPane.DRAG_LAYER); // 3. 🔹 DRAG_LAYER로 변경하여 승패 화면 위에 오도록 🔹
        RestartButton.setVisible(false);


        // 게임 시작 타이머
		Timer timer = new Timer(3000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                gameStartImageLabel.setVisible(false);
                layeredPane.remove(gameStartImageLabel);
                initCharacterSelectionPhase(); // 0단계에서 1단계로 전환
                revalidate();
                repaint();
            }
        });
        timer.setRepeats(false);
        timer.start();


		// ====================================================================================================
		// 이벤트 리스너 설정

		OkayBtn.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		        String inputText = inputField.getText().trim();
		        if (inputText.isEmpty()) {
		            logWithDelay("숫자를 입력해주세요.", textArea, 0, null);
		            return;
		        }

		        try {
		            lastInputNumber = Integer.parseInt(inputText);
		            if (lastInputNumber < 1 || lastInputNumber > 5) {
		                logWithDelay("1~5 사이의 숫자를 입력해주세요.", textArea, 0, null);
		                return;
		            }
		        } catch (NumberFormatException ex) {
		            logWithDelay("유효하지 않은 숫자 형식입니다. 다시 입력해주세요.", textArea, 0, null);
		            return;
		        }

		        System.out.println("입력 숫자 저장됨: " + lastInputNumber);

		        if (phase == 1) { // 플레이어 캐릭터 선택
		            player = RealMakePokemon(lastInputNumber);
		            if (player != null) {
		                logWithDelay(player.name + "이(가) 내 캐릭터로 선택되었습니다.", textArea, 0, null);
                        // 1. 🔹 캐릭터 선택 중 화면으로 전환 🔹
                        charSelectBackgroundLabel.setVisible(false); // 기존 선택 배경 숨김
                        charSelectingBackgroundLabel.setVisible(true); // "선택 중" 배경 보이기
                        hideAllPokemonImages(playerPokemonImageLabels); // 기존 플레이어 이미지 모두 숨김
		                playerPokemonImageLabels.get(player.name).setVisible(true); // 선택된 플레이어 포켓몬 이미지 보이기
                        // 이 이미지들이 charSelectingBackgroundLabel 위에 오도록, createAndAddPokemonImageLabel에서 레이어 조정 필요 (PALETTE_LAYER)

		                MyPokemonNameLabel.setText(player.name);
		                MyPokemonNameLabel.setVisible(true);

		                MYRealHP.setText(String.valueOf(player.getMaxHp()));
                        MYFullHP.setText(String.valueOf(player.getMaxHp()));
		                MyprogressBar.setMaximum(player.getMaxHp());
		                MyprogressBar.setValue(player.getHp());

		                inputField.setText("");
		                logWithDelay("2. 대결할 상대의 캐릭터 숫자를 입력하세요: 1.피카츄 2.파이리 3.수댕이 4.아르세우스 5.디아루가", textArea, 0, null);
		                phase = 2; // 다음 단계로 전환 (타겟 선택)
		            } else {
		                logWithDelay("캐릭터 생성에 실패했습니다. 다시 시도해주세요.", textArea, 0, null);
		            }
		        } else if (phase == 2) { // 타겟 캐릭터 선택
		            target = RealMakePokemon(lastInputNumber);
		            if (target != null) {
		                logWithDelay(target.name + "이(가) 싸울 상대로 선택되었습니다.", textArea, 0, null);
		                hideAllPokemonImages(targetPokemonImageLabels); // 기존 타겟 이미지 모두 숨김
		                targetPokemonImageLabels.get(target.name).setVisible(true); // 선택된 타겟 포켓몬 이미지 보이기
                        // 이 이미지들이 charSelectingBackgroundLabel 위에 오도록, createAndAddPokemonImageLabel에서 레이어 조정 필요 (PALETTE_LAYER)

		                EnemyPokemonNameLabel.setText(target.name);
		                EnemyPokemonNameLabel.setVisible(true);

		                EnemyRealHP.setText(String.valueOf(target.getMaxHp()));
		                EnemyFullHP.setText(String.valueOf(target.getMaxHp()));
		                EnemyprogressBar.setMaximum(target.getMaxHp());
		                EnemyprogressBar.setValue(target.getHp());

		                inputField.setText("");
		                logWithDelay("==============Game Start==============", textArea, 0, null);
		                initBattlePhase(); // 전투 시작 단계로 전환
		                phase = 3; // 전투 단계로 전환 (플레이어 턴)
		            } else {
		                logWithDelay("캐릭터 생성에 실패했습니다. 다시 시도해주세요.", textArea, 0, null);
		            }
		        } else {
		            logWithDelay("이미 두 캐릭터가 선택되었습니다. 전투가 진행 중입니다.", textArea, 0, null);
		        }
		    }
		});


		AttackButton0.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (phase != 3) return;

				if (player.weapons[0] == null) {
					logWithDelay(player.name + "의 " + AttackButton0.getText() + "는 더 이상 사용할 수 없습니다.", textArea, 0, null);
					AttackButton0.setEnabled(false);
					return;
				}

				AttackButton0.setEnabled(false);
				AttackButton1.setEnabled(false);

				logWithDelay(player.name + "이(가) " + player.weapons[0].getName() + "을(를) 사용합니다.", textArea, 0, () -> {
				    attack(player, target, 0, () -> { // 공격 실행 후 콜백으로 다음 처리
				        // 2. 🔹 공격 로그 중복 출력 수정: 여기서는 checkGameOver만 호출하고 턴 전환 로직은 attack 내부 콜백에서 처리 🔹
                        if (phase == 3) { // 아직 전투 중이면 (게임 오버가 아닐 경우)
                            logWithDelay("상대방의 턴입니다...", textArea, 4000, () -> { // 상대방 턴 시작 메시지
                                handleEnemyTurn(); // 적 턴 처리 메소드 호출
                            });
                        }
				    });
				});
			}
		});

        AttackButton1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (phase != 3) return;

				if (player.weapons[1] == null) {
					logWithDelay(player.name + "의 " + AttackButton1.getText() + "는 더 이상 사용할 수 없습니다.", textArea, 0, null);
					AttackButton1.setEnabled(false);
					return;
				}

				AttackButton0.setEnabled(false);
				AttackButton1.setEnabled(false);

                logWithDelay(player.name + "이(가) " + player.weapons[1].getName() + "을(를) 사용합니다.", textArea, 0, () -> {
				    attack(player, target, 1, () -> {
				        if (phase == 3) {
				            logWithDelay("상대방의 턴입니다...", textArea, 4000, () -> {
				                handleEnemyTurn();
				            });
				        }
				    });
				});
            }
        });

        RestartButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                initGame();
            }
        });
	}


	// ====================================================================================================
	// 헬퍼 메소드

    // createAndAddPokemonImageLabel 메소드 수정: JLayeredPane 레이어 값 추가
    private void createAndAddPokemonImageLabel(String pokemonName, Map<String, JLabel> imageMap, int x, int y, int width, int height, Integer layer) {
        JLabel label = new JLabel("");
        label.setIcon(new ImageIcon(PokemonAttack.class.getResource("/images/" + pokemonName + "2.png")));
        label.setBounds(x, y, width, height);
        layeredPane.add(label, layer); // 레이어 값 인자로 받아서 사용
        label.setVisible(false);
        imageMap.put(pokemonName, label);
    }

    private void hideAllPokemonImages(Map<String, JLabel> imageMap) {
        for (JLabel label : imageMap.values()) {
            label.setVisible(false);
        }
    }

	CharacterP.Character RealMakePokemon(int num){
		System.out.println("포켓몬 생성중");

        Character c;

        switch (num) {
            case 1:
                c=new 피카츄("피카츄",100,15);
                c.showInfo();
                return c;
            case 2:
                c=new 파이리("파이리",110,18);
                c.showInfo();
                return c;
            case 3:
                c=new 수댕이("수댕이",120,16);
                c.showInfo();
                return c;
            case 4:
            c=new 아르세우스("아르세우스",200,25);
                c.showInfo();
                return c;

            case 5:
                c=new 디아루가("디아루가",180,22);
                c.showInfo();
                return c;

            default:
                System.out.println("1~5 사이의 숫자를 입력해주세요.");
                return null;
        }
    }

    // 2. 🔹 attack 메소드 내부 로그 출력 순서 및 콜백 재정비 🔹
    private void attack(Character attacker, Character targetChar, int selectedWeaponIndex, Runnable callback){
        try{
            Weapon selectedWeapon = attacker.weapons[selectedWeaponIndex];
            if (selectedWeapon == null) {
                logWithDelay(attacker.name + "의 " + (selectedWeaponIndex == 0 ? "첫 번째" : "두 번째") + " 무기를 더 이상 사용할 수 없습니다!", textArea, 0, callback);
                if (attacker == player) {
                    if (selectedWeaponIndex == 0) AttackButton0.setEnabled(false);
                    else AttackButton1.setEnabled(false);
                }
                return;
            }

            // 공격 시작 메시지
            logWithDelay(attacker.name + "이(가) " + selectedWeapon.getName() + "을(를) 사용합니다!", textArea, 0, () -> { // 바로 출력
                int originalTargetHp = targetChar.getHp();

                if (attacker.name.equals("디아루가") && selectedWeapon.getName().equals("미래 조율기")) {
                    logWithDelay("시간의 흐름으로 침입한다.. 그리고 미래를 뒤바꾼다!", textArea, 4000, () -> {
                        logWithDelay("디아루가 이(가) 시간의 흐름을 바꿔 공격권을 한번 더 얻었습니다.", textArea, 4000, () -> {
                            selectedWeapon.weaponAttack(attacker, targetChar);
                            selectedWeapon.weaponAttack(attacker, targetChar);
                            processDamageLog(attacker, targetChar, originalTargetHp, selectedWeapon, callback);
                        });
                    });
                } else {
                    selectedWeapon.weaponAttack(attacker, targetChar);
                    processDamageLog(attacker, targetChar, originalTargetHp, selectedWeapon, callback);
                }
            });
        }catch(NullPointerException e) {
            logWithDelay(attacker.name + "의 무기 중 하나가 사라졌습니다. 다른 무기를 선택해주세요.", textArea, 0, callback);
            if (attacker == player) {
                if (selectedWeaponIndex == 0) {
                    AttackButton0.setEnabled(false);
                } else {
                    AttackButton1.setEnabled(false);
                }
            }
        }
    }


	public void logWithDelay(String msg ,JTextArea textArea, int delayMillis, Runnable callback) {
        Timer logTimer = new Timer(delayMillis, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                textArea.append(msg + "\n");
                textArea.setCaretPosition(textArea.getDocument().getLength());
                if (callback != null) {
                    callback.run();
                }
                ((Timer)e.getSource()).stop();
            }
        });
        logTimer.setRepeats(false);
        logTimer.start();
	}

    public void log(String msg ,JTextArea textArea) {
        logWithDelay(msg, textArea, 0, null);
    }


    private void processDamageLog(Character attacker, Character targetChar, int originalTargetHp, Weapon selectedWeapon, Runnable callback) {
        int damageDealt = originalTargetHp - targetChar.getHp();
        if (damageDealt > 0) {
            logWithDelay(targetChar.name + "이(가) " + damageDealt + "만큼의 데미지를 입었다!", textArea, 4000, () -> {
                handleSpecialWeaponEffectsLog(attacker, targetChar, selectedWeapon, originalTargetHp, callback);
            });
        } else if (damageDealt < 0) {
            logWithDelay(attacker.name + "이(가) " + Math.abs(damageDealt) + "만큼의 데미지를 입었다!", textArea, 4000, () -> {
                 handleSpecialWeaponEffectsLog(attacker, targetChar, selectedWeapon, originalTargetHp, callback);
            });
        } else {
            handleSpecialWeaponEffectsLog(attacker, targetChar, selectedWeapon, originalTargetHp, callback);
        }
    }

    private void handleSpecialWeaponEffectsLog(Character attacker, Character targetChar, Weapon selectedWeapon, int originalTargetHp, Runnable callback) {
        if (attacker.name.equals("아르세우스") && selectedWeapon.getName().equals("창조의 판")) {
            // 창조의 판 성공/실패 여부를 판단
            if (attacker.weapons[1] == null) { // 무기가 사라졌으면 성공 (데미지를 입혔든 안 입혔든)
                logWithDelay("창조의 판을 발동한다! 아르세우스의 신성한 힘이 깨어난다...!", textArea, 4000, () -> {
                    if (attacker == player) {
                        AttackButton1.setEnabled(false); // 플레이어의 아르세우스일 경우 버튼 비활성화
                    }
                    logWithDelay("아르세우스의 '창조의 판'이 사라졌습니다.", textArea, 4000, () -> {
                        updateAndCallCallback(attacker, targetChar, callback);
                    });
                });
            } else { // 무기가 사라지지 않았으면 실패
                logWithDelay("창조의 판 발동에 실패했다...", textArea, 4000, () -> {
                    updateAndCallCallback(attacker, targetChar, callback);
                });
            }
        } else { // 일반 공격이거나 다른 특수 무기
            updateAndCallCallback(attacker, targetChar, callback);
        }
    }


    private void updateAndCallCallback(Character attacker, Character targetChar, Runnable callback) {
        updateCharacterHPDisplay(player, MYRealHP, MYFullHP, MyprogressBar);
        updateCharacterHPDisplay(target, EnemyRealHP, EnemyFullHP, EnemyprogressBar);
        logWithDelay(player.name + "의 현재 HP: " + player.getHp() + "  " + targetChar.name + "의 현재 HP: " + target.getHp(), textArea, 4000, callback);
    }

    // 2. 🔹 적 턴 처리 메소드 분리 🔹
    private void handleEnemyTurn() {
        int targetWeaponIndex;
        if (target.weapons[0] != null && target.weapons[1] != null) {
            targetWeaponIndex = (new Random()).nextInt(2);
        } else if (target.weapons[0] != null) {
            targetWeaponIndex = 0;
        } else if (target.weapons[1] != null) {
            targetWeaponIndex = 1;
        } else {
            logWithDelay(target.name + "이(가) 더 이상 사용할 무기가 없습니다!", textArea, 4000, () -> {
                phase = 3; // 다시 플레이어 턴으로
                AttackButton0.setEnabled(player.weapons[0] != null);
                AttackButton1.setEnabled(player.weapons[1] != null);
                checkGameOver();
            });
            return;
        }

        logWithDelay(target.name + "이(가) " + target.weapons[targetWeaponIndex].getName() + "을(를) 사용합니다.", textArea, 0, () -> {
            attack(target, player, targetWeaponIndex, () -> {
                phase = 3; // 턴 종료 후 다시 플레이어 턴으로
                AttackButton0.setEnabled(player.weapons[0] != null);
                AttackButton1.setEnabled(player.weapons[1] != null);
                checkGameOver();
            });
        });
    }


	private void updateCharacterHPDisplay(Character character, JLabel realHPLabel, JLabel fullHPLabel, JProgressBar progressBar) {
	    int currentHp = character.getHp();
	    if (currentHp < 0) currentHp = 0;
	    realHPLabel.setText(String.valueOf(currentHp));
	    fullHPLabel.setText(String.valueOf(character.getMaxHp()));
	    progressBar.setValue(currentHp);
	}

	private void initCharacterSelectionPhase() {
	    // 모든 전투 및 게임 종료 관련 UI 숨김
	    hideAllPokemonImages(playerPokemonImageLabels);
	    hideAllPokemonImages(targetPokemonImageLabels);
        backgroundLabel.setVisible(false);
        gameStartImageLabel.setVisible(false);
        victoryImageLabel.setVisible(false);
        defeatImageLabel.setVisible(false);
        RestartButton.setVisible(false);

	    MyPokemonNameLabel.setVisible(false);
	    EnemyPokemonNameLabel.setVisible(false);
	    MYRealHP.setVisible(false);
	    MYFullHP.setVisible(false);
	    MyprogressBar.setVisible(false);
	    EnemyRealHP.setVisible(false);
	    EnemyFullHP.setVisible(false);
	    EnemyprogressBar.setVisible(false);
        bar.setVisible(false);
        MyHP.setVisible(false);
        EnemyHP.setVisible(false);
        bar2.setVisible(false);

	    AttackButton0.setVisible(false);
	    AttackButton1.setVisible(false);
        charSelectingBackgroundLabel.setVisible(false); // 혹시 이전 단계에서 보였을 경우 숨김

	    // 1. 🔹 캐릭터 선택 초기 배경 이미지 보이기 🔹
        charSelectBackgroundLabel.setVisible(true);

	    // 캐릭터 선택 관련 UI만 보이게 (입력 필드와 확인 버튼은 PALETTE_LAYER 위에 오도록 함)
	    inputField.setVisible(true);
	    OkayBtn.setVisible(true);

	    textArea.setText("");
        log("포켓몬 게임을 시작합니다!",textArea);
	    log("안내: 아래 텍스트박스에 숫자를 입력하고 확인을 클릭합니다.",textArea);
	    log("본인의 캐릭터, 싸울 캐릭터를 선정할 수 있습니다.",textArea);
	    log("캐릭터는 총 5종입니다 ・・・ 1.피카츄 2.파이리 3.수댕이 4.아르세우스 5.디아루가",textArea);
	    log("본인의 캐릭터에 해당하는 숫자를 입력한 뒤 확인 버튼을 클릭, 싸울 캐릭터를 선택한뒤 확인 버튼을 클릭해주세요.",textArea);

        phase = 1; // 캐릭터 선택 단계 (초기)
	}

	private void initBattlePhase() {
	    inputField.setVisible(false);
	    OkayBtn.setVisible(false);
        charSelectBackgroundLabel.setVisible(false); // 캐릭터 선택 배경 숨김
        charSelectingBackgroundLabel.setVisible(false); // 캐릭터 선택 중 배경 숨김
        RestartButton.setVisible(false); // 전투 중에는 재시작 버튼 숨김

        backgroundLabel.setVisible(true); // 숲 전투 배경 보이게

	    AttackButton0.setVisible(true);
        if (player.weapons != null && player.weapons.length > 1 && player.weapons[1] != null) {
            AttackButton1.setText(player.weapons[1].getName());
            AttackButton1.setVisible(true);
            AttackButton1.setEnabled(true);
        } else {
            AttackButton1.setVisible(false);
        }
        AttackButton0.setText(player.weapons[0].getName());
        AttackButton0.setEnabled(true);


	    MyPokemonNameLabel.setVisible(true);
	    EnemyPokemonNameLabel.setVisible(true);
	    MYRealHP.setVisible(true);
	    MYFullHP.setVisible(true);
	    MyprogressBar.setVisible(true);
	    EnemyRealHP.setVisible(true);
	    EnemyFullHP.setVisible(true);
	    EnemyprogressBar.setVisible(true);
        bar.setVisible(true);
        MyHP.setVisible(true);
        EnemyHP.setVisible(true);
        bar2.setVisible(true);


	    logWithDelay("==============전투 시작!==============",textArea, 0, null);
	    logWithDelay(player.name + " vs " + target.name + " 전투 시작!", textArea, 0, null);
	    logWithDelay("무기를 선택하세요!", textArea, 0, null);
	}

	private void checkGameOver() {
	    if (player.getHp() <= 0) {
	        phase = 5; // 게임 종료 단계로 전환
	        logWithDelay(player.name + "이(가) 쓰러졌습니다! 게임 오버!", textArea, 4000, () -> showGameOver("패배"));
	    } else if (target.getHp() <= 0) {
	        phase = 5; // 게임 종료 단계로 전환
	        logWithDelay(target.name + "이(가) 쓰러졌습니다! 승리!", textArea, 4000, () -> showGameOver("승리"));
	    }
	}

	private void showGameOver(String result) {
	    // 모든 전투 UI 숨기기
	    AttackButton0.setEnabled(false); AttackButton0.setVisible(false);
	    AttackButton1.setEnabled(false); AttackButton1.setVisible(false);
	    inputField.setEnabled(false); inputField.setVisible(false);
	    OkayBtn.setEnabled(false); OkayBtn.setVisible(false);
        backgroundLabel.setVisible(false);
        hideAllPokemonImages(playerPokemonImageLabels);
        hideAllPokemonImages(targetPokemonImageLabels);
        MyPokemonNameLabel.setVisible(false); EnemyPokemonNameLabel.setVisible(false);
        MYRealHP.setVisible(false); MYFullHP.setVisible(false); MyprogressBar.setVisible(false);
        EnemyRealHP.setVisible(false); EnemyFullHP.setVisible(false); EnemyprogressBar.setVisible(false);
        bar.setVisible(false); MyHP.setVisible(false); EnemyHP.setVisible(false); bar2.setVisible(false);
        charSelectBackgroundLabel.setVisible(false);
        charSelectingBackgroundLabel.setVisible(false); // 혹시 보여지고 있다면 숨김

	    logWithDelay("게임이 종료되었습니다. 결과: " + result, textArea, 4000, () -> {
            // 3. 🔹 승리/패배 이미지 화면 표시 🔹
            if (result.equals("승리")) {
                victoryImageLabel.setVisible(true);
                defeatImageLabel.setVisible(false);
            } else {
                victoryImageLabel.setVisible(false);
                defeatImageLabel.setVisible(true);
            }
            // 3. 🔹 재시작 버튼 표시 (승리/패배 화면 위에) 🔹
            RestartButton.setVisible(true);
            RestartButton.setEnabled(true);
        });
	}

    private void initGame() {
        player = null;
        target = null;
        lastInputNumber = -1;
        phase = 0;

        hideAllPokemonImages(playerPokemonImageLabels);
        hideAllPokemonImages(targetPokemonImageLabels);
        backgroundLabel.setVisible(false);
        charSelectBackgroundLabel.setVisible(false);
        charSelectingBackgroundLabel.setVisible(false);
        victoryImageLabel.setVisible(false);
        defeatImageLabel.setVisible(false);
        RestartButton.setVisible(false);
        RestartButton.setEnabled(false);

        MyPokemonNameLabel.setVisible(false);
        EnemyPokemonNameLabel.setVisible(false);
        MYRealHP.setVisible(false);
        MYFullHP.setVisible(false);
        MyprogressBar.setVisible(false);
        EnemyRealHP.setVisible(false);
        EnemyFullHP.setVisible(false);
        EnemyprogressBar.setVisible(false);
        bar.setVisible(false);
        MyHP.setVisible(false);
        EnemyHP.setVisible(false);
        bar2.setVisible(false);

        AttackButton0.setVisible(false);
        AttackButton1.setVisible(false);
        inputField.setVisible(false);
        OkayBtn.setVisible(false);
        textArea.setText("");

        // 게임 시작 이미지 다시 표시
        layeredPane.add(gameStartImageLabel, JLayeredPane.PALETTE_LAYER);
        gameStartImageLabel.setVisible(true);

        revalidate();
        repaint();

        // 0단계 -> 1단계(캐릭터 선택)로 전환하는 타이머
        Timer restartTimer = new Timer(3000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                gameStartImageLabel.setVisible(false);
                layeredPane.remove(gameStartImageLabel);
                initCharacterSelectionPhase(); // 1단계로 진입
                revalidate();
                repaint();
                ((Timer)e.getSource()).stop();
            }
        });
        restartTimer.setRepeats(false);
        restartTimer.start();
    }


	public void updateEnemyHP(int hp) { /* 사용되지 않음 */ }
	public void appendBattleLog(String string) { /* 사용되지 않음 */ }
}