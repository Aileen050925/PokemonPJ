package CharacterP;
import WeaponP.Weapon;
import CharacterP.Character;
public abstract class Attackable {
    public abstract void attack(Character target, Weapon weapon);
    
} 