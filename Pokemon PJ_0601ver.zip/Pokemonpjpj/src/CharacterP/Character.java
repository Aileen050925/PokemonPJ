package CharacterP;

import WeaponP.Weapon;

public class Character extends Attackable {
    public String name;
    private int hp;
    private int power;
    private int maxHp; // 1. 🔹 maxHp 필드 추가 🔹
    public String attribute;
    public Weapon[] weapons = new Weapon[2];
	private int p;

    //생성자
    public Character(){}
    public Character(String name, int hp, int power){
        this.name=name;
        this.hp=hp;
        this.power=power;
        this.maxHp=hp; // 1. 🔹 maxHp 초기화 🔹

        System.out.println(this.name+"을(를) 생성했다!");
    }

    //Getter,Setter
    public int getHp(){
        return this.hp;
    }
    public void setHp(int h){
        this.hp=h;
    }

    public int getPower(){
        return this.power;
    }
    public void setPower(int p){
        this.p=p;
    }

    // 1. 🔹 maxHp Getter 추가 🔹
    public int getMaxHp() {
        return this.maxHp;
    }

    public void showInfo(){
        System.out.println(" ");
        System.out.printf("== %s ==\n",this.name);
        System.out.printf("hp: %d   power:%d    \n",this.hp, this.power);
        System.out.println(" ");
    }

    public void attack (Character target, Weapon weapon){
        weapon.weaponAttack(this,target);
        return;
    }

    public void receiveDamage (int damage){
        this.setHp(this.getHp()-damage);
    }
}